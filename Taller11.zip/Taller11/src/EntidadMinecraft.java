public interface EntidadMinecraft {
    void aparecer();
    void interactuar();
    String obtenerTipo();
}